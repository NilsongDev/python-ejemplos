# variables asignadas 
num1 = 8
num2 = 10.5
palabra = "ejercicio"

# Crear diccionario
mi_set = {num1, num2, palabra}

# Crear una lista que contiene todo y el valor false
mi_lista = [mi_set, False]

# Imprimir
print("Contenido de mi_lista:")
print(f"mi_lista = {mi_lista}")

print("\nContenido de mi_set:")
print(f"mi_set = {list(mi_set)}")  # Convertir el set a lista para una vista tipo array