# Solicitar datos de tres personas
numeroFactorial = input("Número factorial: ")

contador = int(numeroFactorial)

while contador > 0:
    print(f"Los números son: {contador}")
    contador -= 1